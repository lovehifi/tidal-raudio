#!/bin/sh

#Environment=LD_LIBRARY_PATH=/usr/ifi/ifi-tidal/Tidal-Connect-Armv7/lib
export LD_LIBRARY_PATH=/usr/ifi/ifi-tidal/Tidal-Connect-Armv7/lib

case "$1" in
	start)
echo "Starting Tidal Connect.."
/usr/ifi/ifi-tidal/Tidal-Connect-Armv7/bin/tidal_connect \
   --tc-certificate-path "/usr/ifi/ifi-tidal/Tidal-Connect-Armv7/id_certificate/IfiAudio_ZenStream.dat" \
   -f "Tidal" \
   --codec-mpegh true \
   --codec-mqa false \
   --model-name "TidalConnect" \
   --disable-app-security false \
   --disable-web-security false \
   --enable-mqa-passthrough true \
   --playback-device "default" \
   --log-level 3 \
   --enable-websocket-log "0" \
	;;

	stop)
	echo "Tidal Connect Container Stopped.."
	;;
	*)
		echo
		echo -e "Usage: $0 [start|stop]"
		echo
		exit 1
	;;
esac

