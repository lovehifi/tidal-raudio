#!/bin/sh
Environment=LD_LIBRARY_PATH=/usr/libilp32
param=$1
[ -z "$param" ] && exit

case "$param" in
"start")
    list="upmpdcli mympd mpd"
    for x in $list; do
	sudo systemctl stop $x
	sudo systemctl disable $x
    done
    sudo systemctl start avahi-daemon
    sudo cp -f /opt/tidal/asound.conf /etc/
    sudo cp -f /opt/utils/curl/libcurl.so.4.6.0 /usr/libilp32/libcurl.so.4.5.0
	
    sudo sync
;;
"stop")
    sudo systemctl stop avahi-daemon
    sudo cp -f /opt/utils/asound.conf /etc/
    sudo cp -f /opt/utils/curl/libcurl.so.4.5.0 /usr/libilp32/libcurl.so.4.5.0
    sudo sync
;;
esac
