#!/bin/sh
sudo touch /var/run/dbus/pid
sudo /usr/local/etc/init.d/avahi start
